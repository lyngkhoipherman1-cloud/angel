// Fullscreen toggle button
const fsBtn = document.getElementById('fullscreenBtn');
fsBtn.addEventListener('click', () => {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen().catch(()=>{/* ignore */});
  } else {
    document.exitFullscreen().catch(()=>{/* ignore */});
  }
});
